Must be ran using Node.JS.

To ensure the website runs correctly Three.JS and Whitestorm.js must also be in the same file directory
as the website.