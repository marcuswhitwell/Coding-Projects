<div id="footer" class="row">
		<div class="col c12 aligncenter">
			<h3>&copy; 2012 Your Name</h3>
			<p><a href="http://andreasviklund.com/templates/origo/">Template design</a> by <a href="http://andreasviklund.com/">Andreas Viklund</a><br />
		Best hosted at <a href="https://www.svenskadomaner.se/?ref=mall&amp;ling=en" title="Svenska Domäner AB">www.svenskadomaner.se</a></p>
		</div>
	</div>
 </div>
</body>
</html>
