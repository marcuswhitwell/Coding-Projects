<div class="col c2">
			<h3>Database:</h3>
		 <p><a href="createDatabase.php">Create Database</a><br />
			<a href="createUserTable.php">Create User Database</a><br />
			<a href="createCourseTable.php">Create Course Table</a> <br />
			<a href="createStudentTakingTable.php">Create Student Taking Table</a></p>
		</div>
	</div>
	