<?php
session_start();
	include ("header.php");
	include ("leftNav.php");
 ?>
		<div class="col c8">
		<?php
		include ("tutorCheck.php");
		if (isset($_POST['courseName']))
		{
			addCourseToDatabase();	
		}
		else
		{
			showForm();
		}
		?>
		</div>	
 <?php
	include ("rightNav.php");
	include ("footer.php");
	
 function showForm()
 {
	echo ("
	<form name='Add Course' method='post' action='tutorNewCourse.php'>
	Course Name <input type='text' name='courseName' /> <br />
				<input type='submit' onclick='submit' />
	</form>
	");
 }
 function addCourseToDatabase()
 {
	 $cn = $_POST['courseName'];
	 $ow = $_SESSION['userID'];
	 
	 $conn = mysqli_connect('localhost','root','', 'aceTraining');
	 $sql = "INSERT INTO course (courseName, courseOwner) VALUES ('$cn', '$ow')";
	 echo ("<p>SQL QUERY: <pre>" . $sql . "</pre></p>");
	 if (mysqli_query($conn, $sql))
		{
		echo ("<p style='colour:green;>SUCCESS</p>");
		}
	 else 
		{
		 echo("<p style='color:red'>FAIL: ");
		 echo (mysqli_error($conn) . "</p>");
		}
 }
 ?>
		
		
		
		
		
		
		
		
		
		
		
 
	