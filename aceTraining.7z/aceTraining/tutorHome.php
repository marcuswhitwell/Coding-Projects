<?php
	include ("header.php");
	include ("leftNav.php");
 ?>
		<div class="col c8">
			<?php include ("tutorCheck.php"); ?>
		</div>
 <?php
	include ("rightNav.php");
	include ("footer.php");
 ?>
		
 
	