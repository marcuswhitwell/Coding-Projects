<?php
	include ("header.php");
	include ("leftNav.php");
 ?>
		<div class="col c8">
		<?php
		$conn = mysqli_connect("localhost","root","","aceTraining");
		$sql = "
		CREATE TABLE user (
		userID INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
		userForename VARCHAR(50) NOT NULL,
		userSurname  VARCHAR(50) NOT NULL, 
		userEmail    VARCHAR(50) NOT NULL,
		userPassword VARCHAR(50) NOT NULL,
		userType     VARCHAR(13) NOT NULL,
		userActive   BOOLEAN NOT NULL
		)
		";
		echo ("<p>SQL QUERY: <pre>" . $sql . "</pre></p>");
		if (mysqli_query($conn,$sql))
			{
			echo ("<p style='color:green'>SUCCESS</p>");
			}
		else
			{
			echo ("<p style='color:red'>FAIL: ");
			echo (mysqli_error($conn) . "</p>");
			}
		?>
		</div>
		
 <?php
	include ("rightNav.php");
	include ("footer.php");
 ?>
		
 
	