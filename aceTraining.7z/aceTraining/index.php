<?php
	include ("header.php");
	include ("leftNav.php");
 ?>
		<div class="col c8">
			<h2>Welcome</h2>
			<p>Welcome to Ace Training</p>
			<h3>Our Mission</h3>
			<p>I'll do this later</p>
		</div>
 <?php
	include ("rightNav.php");
	include ("footer.php");
 ?>
		
 
	