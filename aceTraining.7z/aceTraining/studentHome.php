<?php
	include ("header.php");
	include ("leftNav.php");
 ?>
		<div class="col c8">
			<?php include ("studentCheck.php"); ?>
		</div>
 <?php
	include ("rightNav.php");
	include ("footer.php");
 ?>
		
 
	