<?php
session_start();
	include ("header.php");
	include ("leftNav.php");
 ?>
		<div class="col c8">
			<?php
			if (!isset($_POST['email']))
			{
				showLogin();
			}
			else
			{
				doLogin();
			}
			?>
		</div>
 <?php
	include ("rightNav.php");
	include ("footer.php");
	function showLogin()
	{
		echo ("
			<form name='login' method='post' action='login.php' >
			Email <input type='text' name='email' /> <br />
			Password <input type='password' name='password' /> <br />
			<input type='submit' onclick='submit' />
			</form>
			");
	}
	function doLogin()
	{
		$em = $_POST['email'];
		$pw = $_POST['password'];
		$conn = mysqli_connect("localhost", "root", "", "aceTraining");
		$sql = "SELECT userID, userType FROM user
				WHERE userEmail = '$em' AND userPassword = '$pw' ";
		echo ("<p> SQL QUERY: <pre>" . $sql . "</pre></p>");
		if ($resource = mysqli_query($conn,$sql))
			{
			echo ("<p style='color:green'>SUCCESS</p>");
			showLinkToUserPage();
			checkLogin($resource);
			}
		else
			{
			echo ("<p style='color:red'>FAIL: ");
			echo (mysqli_error($conn) . "</p>");
			}
	}
	
	function checkLogin($resource)
	{
		if (mysqli_num_rows($resource) == 1)
		{
			$row = mysqli_fetch_array($resource);
			$_SESSION['userType'] = $row['userType'];
			$_SESSION['userID'] = $row['userID'];
			echo("<p style='color:green'>LOGIN SUCCESS</p>");
		}
		else
		{
			echo ("<p style='color:red'>LOGIN FAIL: ");
		}
	}
	function showLinkToUserPage()
	{
		if ($_SESSION['userType'] == "tutor")
		{
		echo ("<a href='tutorHome.php'>Click here for tutor home page</a>");
		}
		else if ($_SESSION['userType'] == "student")
		{
		echo ("<a href='studentHome.php'>Click here for student home page</a>");
		}
		else if ($_SESSION['userType'] == "administrator")
		{
		echo ("<a href='administratorHome.php'>Click here for administrator home page</a>");
		}
		else
	    {
		echo ("<a href='login.php'>Something went wrong... Retry Login (Error but link still works, click this)</a>");
		}
	}
 ?>
		
		
		
		
		
		
		
		
		
		
		
		
 
	