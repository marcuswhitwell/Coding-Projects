<?php
	include ("header.php");
	include ("leftNav.php");
 ?>
		<div class="col c8">
		<?php
		if (isset($_POST['forename']))
		{
			addUserToDatabase();	
		}
		else
		{
			showForm();
		}
		?>
		</div>	
 <?php
	include ("rightNav.php");
	include ("footer.php");
 function showForm()
 {
	echo ("
	<form name='register' method='post' action='register.php'>
	Forename			<input type='text' name='forename' />   <br />
	Surname				<input type='text' name='surname'  />   <br />
	Email Address		<input type='text' name='email'	   />   <br />
	Password			<input type='text' name='password' />   <br />
	Confirm Password	<input type='text' name='cpassword'/>   <br />
	Tutor / Student 	<select name='type' />
								<option value='tutor'>Tutor</option>
								<option value='student'>Student</option>
						</select>
						<input type='submit' onClick='submit' />
	</form>
	");
 }
 function addUserToDatabase()
 {
	 $fn = $_POST['forename'];
	 $sn = $_POST['surname'];
	 $em = $_POST['email'];
	 $pw = $_POST['password'];
	 $tp = $_POST['type'];
	 
	 $conn = mysqli_connect('localhost','root','', 'aceTraining');
	 $sql = "INSERT INTO user (userForename, userSurname, userEmail, userPassword, userType, userActive)
			 VALUES ('$fn', '$sn', '$em', '$pw', '$tp', 0)";
	 echo ("<p>SQL QUERY: <pre>" . $sql . "</pre></p>");
	 if (mysqli_query($conn, $sql))
		{
		echo ("<p style='colour:green;>SUCCESS</p>");
		}
	 else 
		{
		 echo("<p style='color:red'>FAIL: ");
		 echo (mysqli_error($conn) . "</p>");
		}
 }
 ?>
		
		
		
		
		
		
		
		
		
		
		
 
	