<?php
	include ("header.php");
	include ("leftNav.php");
 ?>
		<div class="col c8">
			<?php
			session_destroy();
			echo("You have successfully logged out click 'logout' once more.");
			?>
		</div>
 <?php
	include ("rightNav.php");
	include ("footer.php");
 ?>
		
 
	