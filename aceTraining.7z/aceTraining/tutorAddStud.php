<?php
	include ("header.php");
	include ("leftNav.php");
 ?>
		<div class="col c8">
		<?php
		include ("tutorCheck.php");
		if (!isset($_POST['courseID']) AND !isset($_POST['studentID']))
		{	
			if (!isset($_POST['forename']))
			{
				showForm();
			}
			else
			{
				addUserToDatabase();	
				$studentID = getStudentID();
				$resource = getCourses();
				showCourses($resource, $studentID);
			}
		}
		else
		{
			enrolStudent();
		}
		?>
		</div>	
 <?php
	include ("rightNav.php");
	include ("footer.php");
 function showForm()
 {
	echo ("
	<form name='register' method='post' action='tutorAddStud.php'>
	Forename			<input type='text' name='forename' />   <br />
	Surname				<input type='text' name='surname'  />   <br />
	Email Address		<input type='text' name='email'	   />   <br />
						<input type='submit' onClick='submit' />
	</form>
	");
 }
 function addUserToDatabase()
 {
	 $fn = $_POST['forename'];
	 $sn = $_POST['surname'];
	 $em = $_POST['email'];
	
	 $sql = "INSERT INTO user (userForename, userSurname, userEmail, userPassword, userType, userActive)
			 VALUES ('$fn', '$sn', '$em', '$em', 'student', 1)";
	doSQL($sql);
 }
 function getStudentID()
 {
	 $em = $_POST['email'];
	 $sql = "SELECT userID FROM user WHERE userEmail = '$em' ";
	 $record = mysqli_fetch_array(doSQL($sql));
	 $studentID = $record['userID'];
	 return $studentID;
 }
 function getCourses()
 {
	 $tutorID = $_SESSION['userID'];
	 $sql = "SELECT * FROM course WHERE courseOwner = $tutorID";
	 $resource = doSQL($sql);
	 return $resource;
 }
 function showCourses($resource, $studentID)
 {
	 echo ("<form name='showCourses' method='post' action='tutorAddStud.php >");
	 while ($currentLine = mysqli_fetch_array($resource))
		{
		 echo ("<input type='checkbox' name='courseID[]' value='$currentLine[courseID]' />");
		 echo ($currentLine['courseName'] . '<br />');
		}
	 echo ("<br />
			<input type='hidded' name='studentID' value='$studentID' />
			<input type='submit' onclick='submit' />
			</form>");
 }
 function enrolStudent()
 {
	$course = $_POST['courseID'];
	$studentID = $_POST['studentID'];
	$today = date("Ymd");
	
	foreach ($course as $currentCourse)
	{
	$sql = "INSERT INTO studentTaking (courseID, userID, dateRegistered, authorised)
			VALUES ('$currentCourse', '$studentID', '$today', 1)";
	doSQL($sql);
	}
 }
 function doSQL($sql)
 {
	 $conn = mysqli_connect('localhost','root','', 'aceTraining');
	 echo ("<p>SQL QUERY: <pre>" . $sql . "</pre></p>");
	 if ($resource = mysqli_query($conn, $sql))
		{
		echo ("<p style='colour:green;>SUCCESS</p>");
		return $resource;
		}
	 else 
		{
		 echo("<p style='color:red'>FAIL: ");
		 echo (mysqli_error($conn) . "</p>");
		 return false;
		}
 }
 ?>
		
		
		
		
		
		
		
		
		
		
		
 
	