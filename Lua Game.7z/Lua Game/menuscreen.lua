------------------------------------------------------
--Hides the status bar at the top of the mobile device
------------------------------------------------------
display.setStatusBar(display.HiddenStatusBar)

----------
--Requires
----------
require("helpscreen")
require("gamescreen")

-----------------
--Main Functions
-----------------
function menuScreen()

--------------------------------------
--General Code to load the menu screen
--------------------------------------

	-- add a group
	MenuBGgroup = display.newGroup() 
	-- add a background
	MenuBG = display.newImageRect("images/Main_Menu_Final.png", 320, 480)
	-- position the background
	MenuBG.x = display.contentCenterX
	MenuBG.y = display.contentCenterY
	
	--add the background to the group
	MenuBGgroup:insert(MenuBG)
	
	--add a button to move to the help screen
	buttonhelp = display.newImageRect ("images/button.png", 50,23)
	--position the button
	buttonhelp.x = 250
	buttonhelp.y = 425
	--make the button graphic invisible
	buttonhelp.isVisible = false
	buttonhelp.isHitTestable = true
	--add the button to the same group as the background
	MenuBGgroup:insert(buttonhelp)
	
	--add a button to move to the game screen
	buttongame = display.newImageRect ("images/button.png", 50,23)
	--position the button
	buttongame.x = 75
	buttongame.y = 425
	--make the button graphic invisible
	buttongame.isVisible = false
	buttongame.isHitTestable = true
	--add the button to the same group as the background
	MenuBGgroup:insert(buttongame)
	
---------------------------------------------------
--Calls the help screen file when button is pressed
---------------------------------------------------
	function goToHelp(event)
			if event.phase == "began" then
				buttonhelp:removeEventListener("touch", goToHelp)
				--remove the menu screen
				MenuBGgroup: removeSelf()
				MenuBGgroup = nil
				collectgarbage ("collect")
				--launch the helpScreen by calling the function
				helpScreen()
		end
	 end
	buttonhelp:addEventListener("touch", goToHelp)
		
----------------------------------------------
--Calls the game screen when button is pressed
----------------------------------------------
	function goToGame(event)
			if event.phase == "began" then
				buttongame:removeEventListener("touch", goToGame)
				--remove the menu screen
				MenuBGgroup: removeSelf()
				MenuBGgroup = nil
				collectgarbage ("collect")
				--launch the gameScreen by calling the function
				gameScreen()
		end
	 end
	buttongame:addEventListener("touch", goToGame)
end