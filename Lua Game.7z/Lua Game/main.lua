------------------------------------------------------------------------------------------------
--File is called main because it needs that name to be called by corona, This is a splash screen 
------------------------------------------------------------------------------------------------

------------------------------------------------------
--Hides the status bar at the top of the mobile device
------------------------------------------------------
display.setStatusBar(display.HiddenStatusBar)

-----------
--Requires
-----------
require("menuscreen")

----------------
--Main Functions
----------------
function splashScreen()

----------------------------------------
--General code to load the splash screen 
----------------------------------------

	-- add a group
	SplashGroup= display.newGroup() 

	-- add a background
	Splash= display.newImageRect("images/Splash_Screen.png", 320, 480)

	-- position the background
	Splash.x = display.contentCenterX
	Splash.y = display.contentCenterY

	--add the background to the group
	SplashGroup:insert(Splash)

	--add a function to remove the splash screen and launch the menu screen
	function GoToMenu()

		SplashGroup: removeSelf()
		SplashGroup = nil
		collectgarbage ("collect")
		menuScreen()

	end
	
------------------------------------------------------
--Timer to load the splash screen for a few seconds
------------------------------------------------------
	timer.performWithDelay(2000, GoToMenu)



end
splashScreen()
