-- this is the help screen that shows the players how to play the game, It needs to allow the players to go back to the menu--
-- hide status bar --
display.setStatusBar(display.HiddenStatusBar)
------------------------------
-- require
------------------------------
--require("menuscreen")
--------------------------
-- main functions
--------------------------
function helpScreen()

	-- add a group
	HelpGroup= display.newGroup() 

	-- add a background
	Help= display.newImageRect("images/Help_Screen_Final.png", 320, 480)

	-- position the background
	Help.x = display.contentCenterX
	Help.y = display.contentCenterY
	--add the background to the group
	HelpGroup:insert(Help)
	-- add a button 
	buttonhome = display.newImageRect ("images/button.png", 50,23)
	--position the button
	buttonhome.x = 270
	buttonhome.y = 420
	--add to group
	HelpGroup:insert(buttonhome)
	--make it invisable
	buttonhome.isVisible = false
	buttonhome.isHitTestable = true
	
	--create an event that allows the user to move to the menuscreen they press the buttonhome
		function goToMenu(event)
			if event.phase == "began" then
				buttonhome:removeEventListener("touch", goToMenu)
				--remove the help screen
				HelpGroup: removeSelf()
				HelpGroup = nil
				collectgarbage ("collect")
				--launch the menuScreen by calling the function
				menuScreen()
		end
	 end
	buttonhome:addEventListener("touch", goToMenu)
end