------------------------------------------------------
--Hides the status bar at the top of the mobile device
------------------------------------------------------
display.setStatusBar(display.HiddenStatusBar)

------------------------------
-- require
------------------------------
--require("menu screen.lua")

-----------------
--Main Functions
-----------------
function gameOverScreen()

	-- add a group
	GameOverGroup= display.newGroup() 
	-- add a background
	GameOverBG= display.newImageRect("images/Game_Over_Screen_Final.png", 320, 480)

	-- position the background
	GameOverBG.x = display.contentCenterX
	GameOverBG.y = display.contentCenterY

	--add the background to the group
	GameOverGroup:insert(GameOverBG)

function GoToMenu()

		GameOverGroup: removeSelf()
		GameOverGroup = nil
		collectgarbage ("collect")
		menuScreen()

	end
	
------------------------------------------------
--Timer to send the user back to the menu screen 
------------------------------------------------
	timer.performWithDelay(2000, GoToMenu)
	

end

