------------------------------------------------------
--Hides the status bar at the top of the mobile device
------------------------------------------------------
display.setStatusBar(display.HiddenStatusBar)


-----------
--Requires
-----------
require("gameoverscreen")


------------------------
--Setting up the physics
------------------------
local physics = require("physics")
physics.start()
physics.setGravity(0,0)



------------------
--Main Functions
------------------


function gameScreen()

----------------------------
--General Game Screen Setup
----------------------------
local Lives = 3
local Score = 0

	-- add a group
	GameBGGroup= display.newGroup() 
	
	-- add a background
	GameBG= display.newImageRect("images/Game_Screen_Final.png", 320, 480)

	-- position the background
	GameBG.x = display.contentCenterX
	GameBG.y = display.contentCenterY

	--add the background to the group
	GameBGGroup:insert(GameBG)
	
	local BulletSensor = display.newRect (0, 0, 320, 2)
	BulletSensor: setFillColor(255, 255, 255)
	BulletSensor.isVisible = false
	physics.addBody(BulletSensor, "dynamic", {friction = 0, bounce = 0})
	BulletSensor.isSensor= true
	BulletSensor.name = "BulletSensor"

	BulletSensor.collision = onCollision
	BulletSensor:addEventListener("collision", BulletSensor)
	GameBGGroup:insert(BulletSensor)
	
	local BottomSensor = display.newRect (0, 470, 320, 2)
	BottomSensor: setFillColor(255, 255, 255)
	BottomSensor.isVisible = false
	physics.addBody(BottomSensor, "dynamic", {friction = 0, bounce = 0})
	BottomSensor.isSensor= true
	BottomSensor.name = "BottomSensor"

	BottomSensor.collision = onCollision
	BottomSensor:addEventListener("collision", BottomSensor)
	GameBGGroup:insert(BottomSensor)
	--score label
	ScoreLabel= display.newText ("Score", 0, 0, "arial", 12)
	ScoreLabel: setFillColor (255, 255, 255)
	ScoreLabel.x = 20
	ScoreLabel.Y = 20
	GameBGGroup:insert (ScoreLabel)
	
	ScorePoints= display.newText (Score, 0, 0, "arial", 12)
	ScorePoints: setFillColor (255, 255, 255)
	ScorePoints.x = 55
	ScorePoints.Y = 20
	GameBGGroup:insert (ScorePoints)
	
	LivesLabel= display.newText ("Lives", 0, 0, "arial", 12)
	LivesLabel: setFillColor (255, 255, 255)
	LivesLabel.x = 280
	LivesLabel.Y = 20
	GameBGGroup:insert (LivesLabel)
	
	LivesPoints= display.newText (Lives, 0, 0, "arial", 12)
	LivesPoints: setFillColor (255, 255, 255)
	LivesPoints.x = 300
	LivesPoints.Y = 20
	GameBGGroup:insert (LivesPoints)
	--variable for character
	Tank= display.newImageRect("images/Tank.png", 50, 50)
	
	--position the character
	Tank.x = 160
	Tank.y = 350
	halfPlayerWidth = Tank.contentWidth * .5
	physics.addBody(Tank, "static", {friction = 0, bounce = 0})
	Tank.name = "Tank"
	--add character to group
	GameBGGroup:insert(Tank)
	
	buttonLeft = display.newImageRect ("images/button.png", 75,50)
	--position the button
	buttonLeft.x = 45
	buttonLeft.y = 415
	--make the button graphic invisible
	buttonLeft.isVisible = false
	buttonLeft.isHitTestable = true
	--add the button to the same group as the background
	GameBGGroup:insert(buttonLeft)
	
	buttonRight = display.newImageRect ("images/button.png", 75,50)
	--position the button
	buttonRight.x = 278
	buttonRight.y = 415
	--make the button graphic invisible
	buttonRight.isVisible = false
	buttonRight.isHitTestable = true
	--add the button to the same group as the background
	GameBGGroup:insert(buttonRight)
	
	buttonFire = display.newImageRect ("images/button.png", 100,70)
	--position the button
	buttonFire.x = 155
	--height is experimental
	buttonFire.y = 410
	--make the button graphic invisible
	buttonFire.isVisible = false
	buttonFire.isHitTestable = true
	--add the button to the same group as the background
	GameBGGroup:insert(buttonFire)
	
	-----------------------------------------------------
	--Horizontal Movement and Speed, both local variables
	-----------------------------------------------------
	
	motionx = 0 
	
	speed = 10

	---------------------------------------------
	--When the movement stops so should the tank
	---------------------------------------------
	function stop (event)
	if event.phase =="ended" then
		motionx = 0
		motiony = 0
		end
	end	
	Runtime:addEventListener("touch", stop ) 

	--------------------------
	--Tank Movement code 
	--------------------------
	function moveTank (event)
		Tank.x = Tank.x + motionx
	end
	Runtime:addEventListener("enterFrame", moveTank) 


	function buttonLeft:touch()
		motionx = -speed
		motiony = 0
	end
	buttonLeft:addEventListener("touch",buttonLeft)

	function buttonRight:touch()
		motionx = speed
		motiony = 0
	end
	buttonRight:addEventListener("touch",buttonRight)

	------------------------------------------------------------
	--Code to ensure the tank doesnt move off the mobile screen
	------------------------------------------------------------
	function boundaries (event)
		if Tank.x < 34 then
			Tank.x = 34
		end

		if Tank.x > 290 then
			Tank.x = 290
		end
	end
	Runtime:addEventListener("enterFrame", boundaries)
	
	-----------------------------
	--Function to fire the laser
	-----------------------------
	function LaserFire(event)
			Laser = display.newImageRect("images/Bullet.png", 19,19)
			Laser.name = "Laser"
			Laser.x = Tank.x
			Laser.y = Tank.y - halfPlayerWidth
			
			GameBGGroup:insert (Laser)
			physics.addBody(Laser,"dynamic", {bounce = 0, })
		
			Laser.collision = onCollision
			Laser:addEventListener("collision", Laser)
											
			transition.to(Laser, {time = 1500, y = -Laser.contentHeight,})	
	end
	buttonFire:addEventListener("tap",LaserFire)
	
	
	--------------------------
	--Spawning Enemy Ships
	--------------------------
	function spawnShips()
		  Alien = display.newImageRect("images/Alien.png",50, 50)
		  Alien.x = math.random(34, 290);
		  Alien.y = -50;
		  Alien.name = "Alien"
		  transition.to( Alien, { time=math.random(4000,8000) , y=800, } );
		  physics.addBody( Alien, "dynamic", { density=1, bounce=0, friction=0.1,  } );
		  Alien.collision = onCollision
		  Alien:addEventListener("collision", Alien)
		  GameBGGroup:insert(Alien)
	end
	
	----------------------------
	--Code fires every 2 seconds
	----------------------------
	Enemytmr = timer.performWithDelay( 2000, spawnShips, -1	)  
	

	--------------------------
	--Collsion handling events
	--------------------------
	function onCollision(self, event)
		if	self.name == "Laser"  and event.other.name == "Alien" then
			self:removeSelf()
			event.other:removeSelf()
			Score = Score + 50
			ScorePoints.text = Score
			elseif self.name =="Laser" and event.other.name == "BulletSensor" then
			Score = Score - 5
			ScorePoints.text = Score
			self:removeSelf ()
			elseif self.name =="Alien" and event.other.name == "BottomSensor" then
			Score = Score - 50
			ScorePoints.text = Score
			self:removeSelf ()
			elseif self.name =="Alien" and event.other.name == "Tank" then
			Lives = Lives - 1
			LivesPoints.text = Lives
			self:removeSelf() 
			if Lives == 0 then
				GameBGGroup:removeSelf()
				GameBGGroup = nil
				collectgarbage ("collect")
				gameOverScreen()
				Runtime:removeEventListener("touch", stop ) 
				Runtime:removeEventListener("enterFrame", moveTank)
				Runtime:removeEventListener("enterFrame", boundaries)
				timer.cancel( Enemytmr )
				end
		end
	end
	

Runtime:addEventListener("collision", onCollision)



end