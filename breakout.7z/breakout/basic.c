#include <stdio.h>
#include <SFML/Graphics.h>
#include <chipmunk/chipmunk.h>

cpSpace *space;

sfRenderWindow* window;
sfSprite* bat;

cpVect chipmunk_pos;
sfVector2f csfml_pos={350,50};
float angle;

int running=0;
int ticks=0;
void update(int ticks)
{
    int i;
	int steps = 2;
	cpFloat dt = 1.0/60.0/(cpFloat)steps;
	for(i=0; i<steps; i++){
		cpSpaceStep(space, dt);
	}
}

static void drawSprites(void *ptr, void *unused)
{
    cpBody* body=cpShapeGetBody((cpShape *)ptr);
    cpDataPointer type=cpShapeGetUserData((cpShape *)ptr);
    chipmunk_pos=cpBodyGetPosition(body);
    csfml_pos.x=chipmunk_pos.x;
    csfml_pos.y=chipmunk_pos.y;
    angle=cpBodyGetAngle(body);


        if(type==(cpDataPointer)3){
        sfSprite_setPosition(bat,csfml_pos);
        //sfSprite_setRotation(bat,angle);
        sfRenderWindow_drawSprite(window,bat,NULL);
    }
}
static void postStepRemove(cpSpace *space,cpShape *shape,void *unused) {
       cpBody* body=cpShapeGetBody(shape);
       cpSpaceRemoveShape(space, shape);
       cpShapeFree(shape);
       cpSpaceRemoveBody(space, body);
       cpBodyFree(body);
}

static void wallCollision(cpArbiter *arb, cpSpace *space,void *data) {
       cpShape *a,*b;
       cpArbiterGetShapes(arb, &a, &b);
       cpSpaceAddPostStepCallback(space,(cpPostStepFunc)postStepRemove,a,NULL);
}
static void brickCollision(cpArbiter *arb, cpSpace *space,void *data) {
       cpShape *a,*b;
       cpArbiterGetShapes(arb, &a, &b);
       cpSpaceAddPostStepCallback(space,(cpPostStepFunc)postStepRemove,b,NULL);
}

int main(void)
{
    int i,j;
	cpVect gravity = cpv(0,0);
	cpVect bat_pos=cpv(400,550);
	space = cpSpaceNew();
	cpSpaceSetGravity(space, gravity);


    cpFloat bat_mass = 5.5;
    cpFloat bat_radius = 20;


	cpFloat bat_moment = cpMomentForCircle(bat_mass, 0, bat_radius, cpvzero);

    cpBody *body=cpBodyNewStatic();
    cpShape *ceiling = cpSegmentShapeNew(body, cpv(0, 0), cpv(750, 00), 0);
    cpShapeSetUserData(ceiling,(cpDataPointer)0);
    cpShape *ground = cpSegmentShapeNew(body, cpv(0, 600), cpv(750, 600), 0);
    cpShapeSetUserData(ground,(cpDataPointer)0);
    cpShape *left = cpSegmentShapeNew(body, cpv(0,0), cpv(0, 600), 0);
    cpShapeSetUserData(left,(cpDataPointer)0);
    cpShape *right = cpSegmentShapeNew(body, cpv(750,0), cpv(750, 600), 0);
    cpShapeSetUserData(right,(cpDataPointer)0);

    cpShapeSetFriction(ceiling,0);
    cpShapeSetElasticity(ceiling, 1.0);
    cpShapeSetFriction(left,0);
    cpShapeSetElasticity(left, 1.0);
    cpShapeSetFriction(right,0);
    cpShapeSetElasticity(right, 1.0);
	cpShapeSetFriction(ground,0);

	cpSpaceAddShape(space, ceiling);
	cpSpaceAddShape(space, ground);
    cpSpaceAddShape(space, left);
    cpShapeSetCollisionType(left,(cpCollisionType)0);


    cpBody *batBody;
    cpShape *batShape;

    batBody = cpSpaceAddBody(space, cpBodyNew(bat_mass, bat_moment));
    cpBodySetPosition(batBody, cpv(400,550));
    batShape = cpSpaceAddShape(space, cpBoxShapeNew(batBody,64,30,bat_radius));
    cpShapeSetCollisionType(batShape,(cpCollisionType)3);
    cpShapeSetUserData(batShape,(cpDataPointer)3);
    cpShapeSetFriction(batShape, 0);
    cpShapeSetElasticity(batShape, 1.0);

	sfVideoMode mode = {800, 600, 24};
	sfVector2f bat_middle = {50,10};

	sfEvent event;
	running  = 1;
	sfTexture* texture;

    texture=sfTexture_createFromFile("ship.png",NULL);
    bat=sfSprite_create();
    sfSprite_setTexture(bat,texture,sfTrue);
    sfSprite_setOrigin(bat,bat_middle);

 

	window = sfRenderWindow_create(mode, "Asteroid Skeleton", sfResize | sfClose, NULL);
	if(!window){
		puts("Unable to create window, aborting.");
		return 1;
	}

	while(sfRenderWindow_isOpen(window)){
		while(sfRenderWindow_pollEvent(window, &event)){
			if(event.type == sfEvtClosed){
				puts("Closing render window.");
				sfRenderWindow_close(window);
			}
          if(event.type == sfEvtMouseMoved){
            if(event.mouseMove.y>0 && event.mouseMove.y<520){
                bat_pos.x=50;
                bat_pos.y=event.mouseMove.y;
                cpBodySetPosition(batBody,bat_pos);
            }
          }
		}
        sfRenderWindow_display(window);
        sfRenderWindow_clear(window, sfBlack);
        cpSpaceEachShape(space,(cpSpaceShapeIteratorFunc)drawSprites,NULL);
        ticks++;
        update(ticks);
	}

sfSprite_destroy(bat);
cpShapeFree(batShape);
cpBodyFree(batBody);
cpSpaceFree(space);
sfRenderWindow_destroy(window);
return 0;
}
